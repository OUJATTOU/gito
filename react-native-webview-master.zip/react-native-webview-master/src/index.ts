import WebView from './WebView';

export { WebView };
export default WebView;
