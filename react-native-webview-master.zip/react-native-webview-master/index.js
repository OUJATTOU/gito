import WebView from './lib/WebView';

export { WebView };
export default WebView;
